using System.Reflection;

[assembly: AssemblyTitle("Menees.Diffs")]
[assembly: AssemblyDescription("Menees Differencing Core Types")]
