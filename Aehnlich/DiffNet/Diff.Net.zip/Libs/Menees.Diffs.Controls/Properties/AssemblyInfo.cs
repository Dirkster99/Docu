using System.Reflection;

[assembly: AssemblyTitle("Menees.Diffs.Controls")]
[assembly: AssemblyDescription("Menees Differencing Windows Forms Controls")]
[assembly: AssemblyVersion("4.0.2.0")]
[assembly: AssemblyFileVersion("4.0.2.0")]

