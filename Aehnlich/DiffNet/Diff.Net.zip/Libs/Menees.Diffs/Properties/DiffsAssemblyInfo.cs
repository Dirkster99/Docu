using System.Reflection;

[assembly: AssemblyVersion("4.0.2.0")]
[assembly: AssemblyProduct("Menees Differencing Utilities")]
