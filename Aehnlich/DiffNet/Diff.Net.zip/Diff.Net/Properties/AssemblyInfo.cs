using System.Reflection;

[assembly: AssemblyTitle("Diff.Net")]
[assembly: AssemblyDescription("A differencing program written in C#.")]
[assembly: AssemblyVersion("4.0.2.0")]
[assembly: AssemblyFileVersion("4.0.2.0")]

