namespace Menees.Diffs
{
	#region Using Directives

	using System;
	using System.Collections.Generic;
	using System.Diagnostics;
	using System.Linq;
	using System.Text;

	#endregion

	#region public IAddCopy

	public interface IAddCopy
	{
		bool IsAdd { get; }
	}

	#endregion
}
