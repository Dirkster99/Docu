using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Menees.Windows.Forms.dll")]
[assembly: AssemblyDescription("Menees.Windows.Forms.dll")]
[assembly: AssemblyProduct("Menees Utilities")]
[assembly: AssemblyVersion("4.5.*")] // Keep this in sync with .NET's version.
